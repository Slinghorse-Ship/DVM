/*
** SPDX-License-Identifier: BSD-3-Clause
** Copyright Contributors to the OpenEXR Project.
*/

#include <cmath>
#include <cstdio>
#include <limits>
#include <string>
#include <fstream>
#include <memory>

#include <openjph/ojph_arch.h>
#include <openjph/ojph_file.h>
#include <openjph/ojph_params.h>
#include <openjph/ojph_mem.h>
#include <openjph/ojph_codestream.h>
#include <openjph/ojph_message.h>

#include "openexr_decode.h"
#include "openexr_encode.h"
#include "openexr_part.h"
#include "internal_ht_common.h"
#include "internal_ht_quality.h"
#include "internal_legacy_structs.h"

/**
 * OpenJPH output file that is backed by a fixed-size memory buffer
 */
class staticmem_outfile : public ojph::outfile_base
  {
  public:
    /**  A constructor */
    staticmem_outfile() {
        is_open = false;
        max_size = used_size = 0;
        buf = cur_ptr = NULL;
    }
    /**  A destructor */
    ~staticmem_outfile() override {
        is_open = false;
        max_size = used_size = 0;
        buf = cur_ptr = NULL;
    }

    /**  
     *  @brief Call this function to write a codestream to an existing memory buffer
	 *
     * 
     *  @param buf pointer to existing memory buffer.
     *  @param buf_size size of the existing memory buffer.
     */
    void open(void* buf, size_t buf_size) {
        assert(this->is_open == false);

        this->is_open = true;
        this->max_size = buf_size;
        this->used_size = 0;
        this->buf = (ojph::ui8*) buf;
        this->cur_ptr = this->buf;
    }

    /**  
     *  @brief Call this function to write data to the memory file.
     *
     *  This function adds new data to the memory file.  The memory buffer
     *  of the file grows as needed.
     *
     *  @param ptr is a pointer to new data.
     *  @param sz the number of bytes in the new data.
     */
    size_t write (const void* ptr, size_t sz) override
    {
        assert (this->is_open);
        assert (this->buf);
        assert (this->cur_ptr);

        size_t needed_size = (size_t) tell () + sz; //needed size
        if (needed_size > this->max_size) {
            throw std::range_error("Buffer size exceeded");
        }

        // copy bytes into buffer and adjust cur_ptr
        memcpy (this->cur_ptr, ptr, sz);
        cur_ptr += sz;
        used_size = ojph_max (used_size, (size_t) tell ());

        return sz;
    }
    /** 
     *  @brief Call this function to know the file size (i.e., number of 
     *         bytes used to store the file).
     *
     *  @return the file size.
     */
    ojph::si64 tell() override { return cur_ptr - buf; }

    /** 
     *  @brief Call this function to change write pointer location; the 
     *         function can expand file storage.
     *
     *  @return 0 on success, non-zero otherwise.
     */
    int seek (ojph::si64 offset, enum outfile_base::seek origin) override
    {
        if (origin == OJPH_SEEK_SET)
            ; // do nothing
        else if (origin == OJPH_SEEK_CUR)
            offset += tell ();
        else if (origin == OJPH_SEEK_END)
            offset += (ojph::si64) this->used_size;
        else
        {
            assert (0);
            return -1;
        }

        cur_ptr = buf + offset;
        return 0;
    }

    /** Call this function to close the file and deallocate memory
	   *
     *  The object can be used again after calling close
     */
    void close() override{
        is_open = false;
    }

    /** 
     *  @brief Call this function to access memory file data.
	   *
     *  It is not recommended to store the returned value because buffer
     *  storage address can change between write calls.
     *
     *  @return a constant pointer to the data.
     */
    const ojph::ui8* get_data() { return buf; }

    /** 
     *  @brief Call this function to access memory file data (for const 
     *         objects)
	   *
     *  This is similar to the above function, except that it can be used
     *  with constant objects.
     *
     *  @return a constant pointer to the data.
     */
    const ojph::ui8* get_data() const { return buf; }

    /** 
     *  Returns the size of the written data
     *
     *  @return size of the data stored in the file
     */
    size_t get_size() const { return this->used_size; }

  private:
    bool is_open;
    size_t max_size;
    size_t used_size;
    ojph::ui8 *buf;
    ojph::ui8 *cur_ptr;
  };

struct ht_context_cache
{
    std::vector<CodestreamChannelInfo> cs_to_file_ch;
    ojph::codestream cs;
    size_t header_sz = 0;
};

/*
 * Chunk-boundary padding for lossy (irreversible) coding.
 *
 * Every chunk is coded as an independent codestream whose image origin is
 * (0, 0).  With the whole-sample symmetric extension of JPEG 2000, a chunk
 * dimension that is even at any decomposition level puts the fold of the
 * extension on a high-pass position, and the quantization error of the
 * resulting coefficient shows up as a visible step on the last row / column
 * of the chunk.  The fold sits on a low-pass position at every one of the L
 * levels if and only if the coded length n' satisfies
 *
 *     n' == 1 (mod 2^L)
 *
 * (the image origin being 0).  So, for lossy coding, the last row and the
 * last column are replicated until both dimensions satisfy this, and the
 * replicated samples are dropped again after decoding.  The padded size is
 * carried by the SIZ marker of the codestream and L by its COD marker, so
 * nothing has to be added to the chunk header.  This analysis relies on the
 * image origin being (0, 0) and on the codestream having a single tile; if
 * either is ever changed the parity at both ends has to be re-examined.
 *
 * HT_NUM_DECOMPS is the number of decomposition levels the encoder writes
 * and, deliberately, also the largest number the decoder accepts for a
 * padded codestream: the padding is at most 2^L - 1 rows and columns, so
 * bounding L keeps the padded extent within a small, content-independent
 * margin of the chunk size, which the image and tile size limits of the
 * context have already vetted.  A codestream may declare up to 32 levels;
 * anything above this constant is rejected as corrupt.  If the encoder
 * ever needs more levels, raise the constant (files written with the
 * larger value are then rejected by older readers).
 *
 * Returns the padded length, or -1 when num_decomps is out of range or
 * the padded length would no longer fit in a 32-bit dimension.
 */
static const int HT_NUM_DECOMPS = 5;

static inline int64_t
ht_padded_length (int64_t n, int num_decomps)
{
    if (n < 0 || num_decomps < 0 || num_decomps > HT_NUM_DECOMPS) return -1;
    const int64_t m = (int64_t) 1 << num_decomps;
    /* smallest n' >= n with n' == 1 (mod m) */
    const int64_t padded = n + (((1 - n) % m) + m) % m;
    if (padded > (int64_t) std::numeric_limits<int32_t>::max ()) return -1;
    return padded;
}

static void destroy_ht_decompress_context (exr_decode_pipeline_t* decode)
{
    ht_context_cache* ctxt = static_cast<ht_context_cache*> (decode->compression_context);
    delete ctxt;
    decode->compression_context = NULL;
    decode->free_compression_context = NULL;
}

static exr_result_t
ht_undo_impl (
    exr_decode_pipeline_t* decode,
    const void*            compressed_data,
    uint64_t               comp_buf_size,
    void*                  uncompressed_data,
    uint64_t               uncompressed_size)
{
    exr_result_t rv = EXR_ERR_SUCCESS;

    std::unique_ptr<ht_context_cache> legacy_support;

    ht_context_cache* ctxt;
    if (decode->pipe_size >= sizeof (exr_decode_pipeline_v2_t))
    {
        ctxt = static_cast<ht_context_cache*> (decode->compression_context);
        if ( ! ctxt )
        {
            ctxt = new ht_context_cache;
            decode->compression_context = ctxt;
            decode->free_compression_context = &destroy_ht_decompress_context;
        }
    }
    else
    {
        legacy_support = std::make_unique<ht_context_cache>();
        ctxt = legacy_support.get();
    }

    std::vector<CodestreamChannelInfo> &cs_to_file_ch = ctxt->cs_to_file_ch;
    bool resetOffsets = false;
    if (static_cast<std::size_t>(decode->channel_count) != cs_to_file_ch.size ())
    {
        resetOffsets = true;
        cs_to_file_ch.clear();

        /* read the channel map */
        try
        {
            ctxt->header_sz = read_header (
                (uint8_t*) compressed_data, comp_buf_size, cs_to_file_ch);
        }
        catch (...)
        {
            return EXR_ERR_CORRUPT_CHUNK;
        }
    }
    else
    {
        exr_storage_t storage;
        // need to reset this when reading tiles in case the width changes
        // (which happens on partial border tiles)
        if (EXR_ERR_SUCCESS == exr_get_storage(decode->context, decode->part_index, &storage))
        {
            resetOffsets = (storage == EXR_STORAGE_TILED);
        }
        else
            return EXR_ERR_CORRUPT_CHUNK;
    }

    /* this should never be true since read_header() throws an exception if the
       header is larger than comp_buf_size */
    if (ctxt->header_sz > comp_buf_size)
        return EXR_ERR_CORRUPT_CHUNK;

    // the compressed buffer size might change, so can't cache the codestream_sz
    const uint64_t codestream_sz = comp_buf_size - ctxt->header_sz;
    if (codestream_sz == 0)
        return EXR_ERR_CORRUPT_CHUNK;

    if (static_cast<std::size_t>(decode->channel_count) != cs_to_file_ch.size ())
        return EXR_ERR_CORRUPT_CHUNK;

    if (resetOffsets)
    {
        for (int cs_i = 0; cs_i < decode->channel_count; cs_i++)
        {
            int file_i = cs_to_file_ch[cs_i].file_index;
            if (file_i >= decode->channel_count)
                return EXR_ERR_CORRUPT_CHUNK;

            int64_t computedoffset = 0;
            for (int i = 0; i < file_i; ++i)
                computedoffset += (int64_t) decode->channels[i].width *
                    (int64_t) decode->channels[i].bytes_per_element;

            if (computedoffset > std::numeric_limits<std::size_t>::max())
                return EXR_ERR_CORRUPT_CHUNK;

            cs_to_file_ch[cs_i].raster_line_offset = computedoffset;
        }
    }

    ojph::mem_infile infile;
    infile.open (
        reinterpret_cast<const ojph::ui8*> (compressed_data) + ctxt->header_sz,
        codestream_sz);

    ojph::codestream &cs = ctxt->cs;
    cs.restart ();
    cs.read_headers (&infile);

    ojph::param_siz siz = cs.access_siz ();

    ojph::ui32 image_height =
        siz.get_image_extent ().y - siz.get_image_offset ().y;
    ojph::ui32 image_width =
        siz.get_image_extent ().x - siz.get_image_offset ().x;

    if (decode->channel_count != siz.get_num_components ())
        return EXR_ERR_CORRUPT_CHUNK;

    /* The codestream is either exactly the chunk, or (lossy coding) the
     * chunk padded by row / column replication to the size that keeps every
     * fold of the wavelet transform on a low-pass position, see
     * ht_padded_length().  In the padded case the extra rows and columns are
     * decoded and discarded below. */
    bool padded = false;
    if (decode->chunk.width != image_width ||
        decode->chunk.height != image_height)
    {
        ojph::param_cod cod0 = cs.access_cod ();
        const int       nd   = (int) cod0.get_num_decompositions ();
        /* ht_padded_length() returns -1 for an unsupported nd, which can
         * never equal a real extent, so that case is rejected here too. */
        if (cod0.is_reversible () ||
            (int64_t) image_width !=
                ht_padded_length (decode->chunk.width, nd) ||
            (int64_t) image_height !=
                ht_padded_length (decode->chunk.height, nd))
            return EXR_ERR_CORRUPT_CHUNK;
        padded = true;
    }

    for (int cs_i = 0; cs_i < decode->channel_count; cs_i++)
    {
        int file_i = cs_to_file_ch[cs_i].file_index;

        if (padded)
        {
            /* padding is only produced for unsubsampled (interleaved) chunks */
            if (siz.get_downsampling (cs_i).x != 1 ||
                siz.get_downsampling (cs_i).y != 1 ||
                decode->channels[file_i].height != decode->chunk.height ||
                decode->channels[file_i].width != decode->chunk.width ||
                siz.get_recon_height (cs_i) != image_height ||
                siz.get_recon_width (cs_i) != image_width)
                return EXR_ERR_CORRUPT_CHUNK;
        }
        else if (
            decode->channels[file_i].height != siz.get_recon_height (cs_i) ||
            decode->channels[file_i].width != siz.get_recon_width (cs_i) ||
            decode->channels[file_i].height !=
                image_height / siz.get_downsampling (cs_i).y ||
            decode->channels[file_i].width !=
                image_width / siz.get_downsampling (cs_i).x)
            return EXR_ERR_CORRUPT_CHUNK;
    }

    int64_t bpl     = 0;
    bool is_planar  = false;
    for (int16_t c = 0; c < decode->channel_count; c++)
    {
        bpl += (int64_t) decode->channels[c].bytes_per_element *
               (int64_t) decode->channels[c].width;
        if (decode->channels[c].x_samples > 1 ||
            decode->channels[c].y_samples > 1)
        { is_planar = true; }
    }
    if (bpl > INT32_MAX || bpl * decode->chunk.height > (int64_t) PTRDIFF_MAX)
        return EXR_ERR_CORRUPT_CHUNK;
    if (padded && is_planar) return EXR_ERR_CORRUPT_CHUNK;
    cs.set_planar (is_planar);

    cs.create ();

    ojph::param_cod cod = cs.access_cod ();
    assert (sizeof (uint16_t) == 2);
    assert (sizeof (uint32_t) == 4);
    ojph::ui32      next_comp = 0;
    ojph::line_buf* cur_line;
    if (cs.is_planar ())
    {
        for (int16_t c = 0; c < decode->channel_count; c++)
        {
            int file_c = cs_to_file_ch[c].file_index;

            if (decode->channels[file_c].height == 0) continue;

            uint8_t* line_pixels = static_cast<uint8_t*> (uncompressed_data);

            /* image_height is an unsigned OpenJPH type; compute the loop
             * bounds in a signed 64-bit type so that a negative start_y
             * (from a negative data-window Y origin) does not get
             * promoted to unsigned and wrap the end condition to a huge
             * positive value, which would cause the loop to run far past
             * the declared image data (CWE-190 / CWE-835). */
            const int64_t start_y = static_cast<int64_t> (decode->chunk.start_y);
            const int64_t end_y   = start_y + static_cast<int64_t> (image_height);

            for (int64_t y = start_y; y < end_y; y++)
            {
                for (int16_t line_c = 0; line_c < decode->channel_count;
                     line_c++)
                {
                    if (y % decode->channels[line_c].y_samples != 0) continue;

                    if (line_c == static_cast<ojph::ui32>(file_c))
                    {
                        cur_line = cs.pull (next_comp);
                        assert (next_comp == c);

                        if (decode->channels[file_c].data_type ==
                            EXR_PIXEL_HALF)
                        {
                            int16_t* channel_pixels = (int16_t*) line_pixels;
                            for (int32_t p = 0;
                                 p < decode->channels[file_c].width;
                                 p++)
                            {
                                if (!cod.is_reversible(c))
                                    *channel_pixels++ = (int16_t) int16_to_half(cur_line->i32[p]).bits();
                                else
                                    *channel_pixels++ = cur_line->i32[p];
                            }
                        }
                        else
                        {
                            uint32_t* channel_pixels = (uint32_t*) line_pixels;
                            for (int32_t p = 0;
                                 p < decode->channels[file_c].width;
                                 p++)
                            {
                                if (!cod.is_reversible(c))
                                    *((float*) channel_pixels++) = int32_to_float(cur_line->i32[p]);
                                else
                                    *channel_pixels++ = (uint32_t) cur_line->i32[p];
                            }
                        }
                    }

                    line_pixels += (size_t) decode->channels[line_c].bytes_per_element *
                                   (size_t) decode->channels[line_c].width;
                }
            }
        }
    }
    else
    {
        uint8_t* line_pixels = static_cast<uint8_t*> (uncompressed_data);

        const uint32_t out_height = (uint32_t) decode->chunk.height;
        assert (bpl * out_height == uncompressed_size);

        /* image_height / image_width are the (possibly padded) codestream
         * dimensions; only the first chunk.height rows and chunk.width
         * samples of each row are copied out, the rest is discarded. */
        for (uint32_t y = 0; y < image_height; ++y)
        {
            for (int16_t c = 0; c < decode->channel_count; c++)
            {
                int file_c = cs_to_file_ch[c].file_index;
                cur_line   = cs.pull (next_comp);
                assert (next_comp == c);
                if (y >= out_height) continue;
                if (decode->channels[file_c].data_type == EXR_PIXEL_HALF)
                {
                    int16_t* channel_pixels =
                        (int16_t*) (line_pixels + cs_to_file_ch[c].raster_line_offset);
                    for (int32_t p = 0; p < decode->channels[file_c].width;
                         p++)
                    {
                        if (!cod.is_reversible(c))
                            *channel_pixels++ = (int16_t) int16_to_half(cur_line->i32[p]).bits();
                        else
                            *channel_pixels++ = cur_line->i32[p];
                    }
                }
                else
                {
                    uint32_t* channel_pixels =
                        (uint32_t*) (line_pixels + cs_to_file_ch[c].raster_line_offset);
                    for (int32_t p = 0; p < decode->channels[file_c].width;
                         p++)
                    {
                        if (!cod.is_reversible(c))
                            *((float*) channel_pixels++) = int32_to_float(cur_line->i32[p]);
                        else
                            *channel_pixels++ = (uint32_t) cur_line->i32[p];
                    }
                }
            }
            line_pixels += bpl;
        }
    }

    infile.close ();

    return rv;
}

extern "C" exr_result_t
internal_exr_undo_ht (
    exr_decode_pipeline_t* decode,
    const void*            compressed_data,
    uint64_t               comp_buf_size,
    void*                  uncompressed_data,
    uint64_t               uncompressed_size)
{
    try
    {
        return ht_undo_impl (decode, compressed_data, comp_buf_size,
                             uncompressed_data, uncompressed_size);
    }
    catch ( ... )
    {
    }

    return EXR_ERR_CORRUPT_CHUNK;
}


////////////////////////////////////////


static exr_result_t
ht_apply_impl (exr_encode_pipeline_t* encode)
{
    exr_result_t rv = EXR_ERR_SUCCESS;

    std::vector<CodestreamChannelInfo> cs_channel_info (encode->channel_count);
    bool                               isRGB = make_channel_map (
        encode->channel_count, encode->channels, cs_channel_info);

    const int chunk_height = encode->chunk.height;
    const int chunk_width  = encode->chunk.width;
    int       image_height = chunk_height;
    int       image_width  = chunk_width;

    ojph::codestream cs;

    ojph::param_siz siz = cs.access_siz ();
    ojph::param_nlt nlt = cs.access_nlt ();

    bool isPlanar = false;
    for (int16_t c = 0; c < encode->channel_count; c++)
    {
        if (encode->channels[c].x_samples > 1 ||
            encode->channels[c].y_samples > 1)
        {
            isPlanar = true;
            break;
        }
    }

    siz.set_num_components (encode->channel_count);
    cs.set_planar (isPlanar);

    exr_compression_t comp = EXR_COMPRESSION_HTJ2K256;
    exr_get_compression (encode->context, encode->part_index, &comp);

    ojph::param_cod cod = cs.access_cod ();

    const int num_decomps = HT_NUM_DECOMPS;

    cod.set_color_transform (isRGB && !isPlanar);
    cod.set_block_dims (128, 32);
    cod.set_num_decomposition (num_decomps);

    /* enable lossy compression on the first 3 channels, only if the compressor
    is EXR_COMPRESSION_LJ2K, we have RGB channels, all RGB channels are
    visual, not UINT and not subsampled */
    bool lossy = comp == EXR_COMPRESSION_LJ2K && isRGB;
    if (lossy) {
        for (int16_t c = 0; c < 3; c++)
        {
            int file_c = cs_channel_info[c].file_index;
            lossy      = lossy &&
                            cs_channel_info[c].kind == J2KChannelKind::visual &&
                            encode->channels[file_c].data_type != EXR_PIXEL_UINT &&
                            encode->channels[file_c].x_samples == 1 &&
                            encode->channels[file_c].y_samples == 1;
        }
    }

    /* Lossy coding: pad the coded array by replicating the last row and the
     * last column so that every dimension is == 1 (mod 2^L); see
     * ht_padded_length().  The padding is only applied to interleaved
     * (unsubsampled) chunks; the decoder recognises it from the SIZ marker. */
    if (lossy && !isPlanar)
    {
        const int64_t pw = ht_padded_length (chunk_width, num_decomps);
        const int64_t ph = ht_padded_length (chunk_height, num_decomps);
        /* If the padded size would not fit in a 32-bit dimension the chunk
         * is coded unpadded; that is still a valid file, the decoder accepts
         * the chunk size as-is. */
        if (pw > 0 && ph > 0)
        {
            image_width  = (int) pw;
            image_height = (int) ph;
        }
    }

    siz.set_image_offset (ojph::point (0, 0));
    siz.set_image_extent (ojph::point (image_width, image_height));

    if (lossy)
    {
        cod.set_reversible (false);

        float qfactor = -1.f;
        exr_get_lossy_htj2k_quality (
            encode->context, encode->part_index, &qfactor);
        if (!is_lossy_htj2k_quality (qfactor)) { return EXR_ERR_INVALID_ARGUMENT; }

        ojph::param_qcd qcd = cs.access_qcd ();

        /*
         * Qfactor is intended for quality levels consistent with 8-bit imagery.
         * It is therefore extended here from 97 to 150 to take into account the
         * fact that OpenEXR accommodates 32-bit imagery.
         */
        if (qfactor < 97.)
        {
            qcd.set_qfactor ((ojph::ui8) std::lround (qfactor));
        }
        else
        {
            double scaled_q = (qfactor - 97.)/53.;
            double delta_ref = 0.005 * pow(2, -28.478*scaled_q) + 0.001 * pow(2, -10.534*scaled_q);

            /*
             * Setting Qstep taking into account the gain from the ICT
             * converting encoded color-difference components to RGB (see
             * "Controlling JPEG 2000 image quality using a single parameter
             * (Qfactor) v2.0").
             */

            /* Y */
            qcd.set_irrev_quant (delta_ref);
            /* Cb */
            qcd.set_irrev_quant (1, delta_ref / sqrt(3.2584/3.));
            /* Cr */
            qcd.set_irrev_quant (2, delta_ref / sqrt(2.4756/3.));

        }

        /* set all channels but the first 3 channels to reversible */
        for (int16_t c = 3; c < encode->channel_count; c++)
        {
            cod.set_reversible (c, true);
        }

    } else {
        cod.set_reversible (true);
    }

    int64_t bpl = 0;
    for (int16_t c = 0; c < encode->channel_count; c++)
    {
        int file_c = cs_channel_info[c].file_index;
        /* only channels that are EXR_PIXEL_HALF or EXR_PIXEL_FLOAT *and* are not lossy and not RGB */
        if (encode->channels[file_c].data_type != EXR_PIXEL_UINT && cod.is_reversible(c))
            nlt.set_nonlinear_transform (
                c,
                ojph::param_nlt::nonlinearity::OJPH_NLT_BINARY_COMPLEMENT_NLT);

        siz.set_component (
            c,
            ojph::point (
                encode->channels[file_c].x_samples,
                encode->channels[file_c].y_samples),
            encode->channels[file_c].data_type == EXR_PIXEL_HALF ? 16 : 32,
            encode->channels[file_c].data_type != EXR_PIXEL_UINT);

        bpl += encode->channels[file_c].bytes_per_element *
               encode->channels[file_c].width;
    }
    if (bpl > INT32_MAX || bpl * encode->chunk.height > (int64_t) PTRDIFF_MAX)
        return EXR_ERR_CORRUPT_CHUNK;

    try
    {
        /* write the header */
        size_t header_sz = write_header (
            (uint8_t*) encode->compressed_buffer,
            encode->packed_bytes,
            cs_channel_info);

        /* write the codestream */
        staticmem_outfile output;
        output.open ( ((uint8_t*) encode->compressed_buffer) + header_sz, encode->packed_bytes - header_sz);

        /* When the chunk is padded, declare it in the codestream itself with
         * a COM marker segment (Rcom = 1, Latin text) in the main header, so
         * that an extracted codestream is self-describing: the last `rows`
         * rows and `cols` columns are extension samples to be discarded
         * after decoding.  Every decoder skips COM segments; the OpenEXR
         * decoder does not need it, since the chunk size tells it what to
         * drop. */
        char                   com_text[64];
        ojph::comment_exchange com;
        ojph::ui32             num_com = 0;
        if (image_height != chunk_height || image_width != chunk_width)
        {
            snprintf (
                com_text,
                sizeof (com_text),
                "OpenEXR LJ2K padding: rows=%d cols=%d",
                image_height - chunk_height,
                image_width - chunk_width);
            com.set_string (com_text);
            num_com = 1;
        }
        cs.write_headers (&output, num_com ? &com : NULL, num_com);

        ojph::ui32      next_comp = 0;
        ojph::line_buf* cur_line  = cs.exchange (NULL, next_comp);

        if (cs.is_planar ())
        {
            for (int16_t c = 0; c < encode->channel_count; c++)
            {
                if (encode->channels[c].height == 0) continue;

                const uint8_t* line_pixels =
                    static_cast<const uint8_t*> (encode->packed_buffer);
                int16_t file_c = cs_channel_info[c].file_index;

                for (int64_t y = encode->chunk.start_y;
                    y < image_height + encode->chunk.start_y;
                    y++)
                {
                    for (int16_t line_c = 0; line_c < encode->channel_count;
                        line_c++)
                    {

                        if (y % encode->channels[line_c].y_samples != 0) continue;

                        if (line_c == file_c)
                        {
                            if (encode->channels[file_c].data_type ==
                                EXR_PIXEL_HALF)
                            {
                                int16_t* channel_pixels = (int16_t*) (line_pixels);
                                for (int32_t p = 0;
                                     p < encode->channels[file_c].width;
                                    p++)
                                {
                                    if (! cod.is_reversible(c))
                                        cur_line->i32[p] = half_to_int16(half (half::FromBits, (uint16_t) (*channel_pixels++)));
                                    else
                                        cur_line->i32[p] = *channel_pixels++;
                                }
                            }
                            else
                            {
                                int32_t* channel_pixels = (int32_t*) (line_pixels);
                                for (int32_t p = 0;
                                     p < encode->channels[file_c].width;
                                    p++)
                                {
                                    if (! cod.is_reversible(c))
                                        cur_line->i32[p] = float_to_int32(*((float *)channel_pixels++));
                                    else
                                        cur_line->i32[p] = *channel_pixels++;
                                }
                            }

                            assert (next_comp == c);
                            cur_line = cs.exchange (cur_line, next_comp);
                        }

                        line_pixels += encode->channels[line_c].bytes_per_element *
                                    encode->channels[line_c].width;
                    }
                }
            }
        }
        else
        {
            const uint8_t* line_pixels =
                static_cast<const uint8_t*> (encode->packed_buffer);

            assert (bpl * chunk_height == encode->packed_bytes);

            /* image_height / image_width may exceed the chunk size by the
             * padding: rows beyond the chunk repeat its last row, samples
             * beyond the chunk width repeat the last sample of the row. */
            for (int y = 0; y < image_height; y++)
            {
                const uint8_t* src_line =
                    line_pixels +
                    (int64_t) (y < chunk_height ? y : chunk_height - 1) * bpl;

                for (int16_t c = 0; c < encode->channel_count; c++)
                {
                    int file_c = cs_channel_info[c].file_index;
                    const int32_t cw     = encode->channels[file_c].width;

                    if (encode->channels[file_c].data_type == EXR_PIXEL_HALF)
                    {
                        int16_t* channel_pixels =
                            (int16_t*) (src_line +
                                        cs_channel_info[c].raster_line_offset);
                        for (int32_t p = 0; p < cw; p++)
                        {
                            if (! cod.is_reversible(c))
                                cur_line->i32[p] = half_to_int16(half (half::FromBits, (uint16_t) (*channel_pixels++)));
                            else
                                cur_line->i32[p] = *channel_pixels++;
                        }
                    }
                    else
                    {
                        int32_t* channel_pixels =
                            (int32_t*) (src_line +
                                        cs_channel_info[c].raster_line_offset);
                        for (int32_t p = 0; p < cw; p++)
                        {
                            if (! cod.is_reversible(c))
                                cur_line->i32[p] = float_to_int32(*((float *)channel_pixels++));
                            else
                                cur_line->i32[p] = *channel_pixels++;
                        }
                    }
                    for (int32_t p = cw; p < image_width; p++)
                        cur_line->i32[p] = cur_line->i32[cw - 1];

                    assert (next_comp == c);
                    cur_line = cs.exchange (cur_line, next_comp);
                }
            }
        }

        cs.flush ();

        assert (output.get_size () >= 0);
        encode->compressed_bytes = output.get_size () + header_sz;
    } catch (const std::range_error& e) {
        /* The codestream is larger than the uncompressed chunk: store the
         * chunk uncompressed, as the other codecs do. */
        if (encode->compressed_alloc_size < encode->packed_bytes)
            return EXR_ERR_OUT_OF_MEMORY;
        memcpy (
            encode->compressed_buffer,
            encode->packed_buffer,
            encode->packed_bytes);
        encode->compressed_bytes = encode->packed_bytes;
    }

    return rv;
}

extern "C" exr_result_t
internal_exr_apply_ht (exr_encode_pipeline_t* encode)
{
    try
    {
        return ht_apply_impl (encode);
    }
    catch ( ... )
    {
    }

    return EXR_ERR_INCORRECT_CHUNK;
}
